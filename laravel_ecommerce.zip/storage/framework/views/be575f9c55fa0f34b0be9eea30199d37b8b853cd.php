<?php $__env->startSection('content'); ?>
    <div class="row" style="margin: 100px 0px;" id="app">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <blog-list></blog-list>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.ecommerce.layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/learn-vue.blade.php ENDPATH**/ ?>