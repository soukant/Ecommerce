<?php $__env->startSection('content'); ?>
<div class="main-container shop-bg">
    <div class="container" id="category_product">
        <category-product></category-product>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.ecommerce.layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/products.blade.php ENDPATH**/ ?>