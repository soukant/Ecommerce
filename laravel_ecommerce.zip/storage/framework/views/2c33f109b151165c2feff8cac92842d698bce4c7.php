<div class="testimonils-area box-shadow mtb-35 bg-fff">
    <div class="product-title home3-bg text-uppercase">
        <i class="fa fa-star-o icon home3-bg2"></i>
        <h3>TESTIMONIALS</h3>
    </div>
    <div class="testmonial-active home2 right left-right-angle">
        <div class="single-testimonil clear">
            <div class="testimonil-content p mtb-25">
                <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim…</p>
            </div>
            <div class="test-img floatleft">
                <img src="<?php echo e(asset('contents/website')); ?>/img/test/2.jpg" alt="" />
            </div>
            <div class="test-info">
                <h6>Kaji Hasibur Rahman</h6>
                <span>Web Designer</span>
            </div>
        </div>
        <div class="single-testimonil clear">
            <div class="testimonil-content p mtb-25">
                <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim…</p>
            </div>
            <div class="test-img floatleft">
                <img src="<?php echo e(asset('contents/website')); ?>/img/test/1.jpg" alt="" />
            </div>
            <div class="test-info">
                <h6>Lorem ipsum</h6>
                <span>CEO of WooThemes</span>
            </div>
        </div>
        <div class="single-testimonil clear">
            <div class="testimonil-content p mtb-25">
                <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim…</p>
            </div>
            <div class="test-img floatleft">
                <img src="<?php echo e(asset('contents/website')); ?>/img/test/1.jpg" alt="" />
            </div>
            <div class="test-info">
                <h6>Lorem ipsum</h6>
                <span>CEO of WooThemes</span>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/hsblco55/oneclick.hsblco.com/resources/views/website/ecommerce/home_include/testimonial.blade.php ENDPATH**/ ?>