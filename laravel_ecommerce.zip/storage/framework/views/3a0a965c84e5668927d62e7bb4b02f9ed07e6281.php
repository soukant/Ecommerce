<div class="">
    <?php if($type == 'text' || $type == 'date' || $type == 'number'): ?>
        <input type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" value="<?php echo e(isset($value)?$value:''); ?>" <?php echo e(isset($attr)?$attr:''); ?> class="form-control"  placeholder="<?php echo e($name); ?>" />
    <?php endif; ?>

    <?php if($type == 'file'): ?>
        <div class="input_file_body" data-toggle="modal" data-target="#fileManagerModal" >
            <div class="overlay"></div>
            <img src="" style="height: 50px;margin: 5px;" alt="preview">
            <input type="text" name="<?php echo e($name); ?>" value="<?php echo e(isset($value)?$value:''); ?>" class="form-control" <?php echo e(isset($attr)?$attr:''); ?>  placeholder="Choose File <?php echo e($name); ?>" />
        </div>
    <?php endif; ?>

    <span class="text-danger <?php echo e($name); ?>"></span>
</div>


<?php /**PATH E:\xampp\htdocs\laravel_ecommerce\resources\views/admin/product/components/input.blade.php ENDPATH**/ ?>