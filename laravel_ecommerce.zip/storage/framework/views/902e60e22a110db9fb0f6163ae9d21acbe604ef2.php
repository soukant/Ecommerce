<?php $__env->startSection('content'); ?>
<div class="main-container">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="menu  mtb-15">
                    <ul>
                        <li><a href="index.html">Home</a></li>
                        <li class="active"><a href="checkout.html">Checkout</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <section id="ceckOutBody">
            <check-out></check-out>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.ecommerce.layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/checkout.blade.php ENDPATH**/ ?>