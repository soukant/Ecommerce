<div class="top-cart home3-top-cart home3-bg bg-5" id="productCart">
    <product-header-cart></product-header-cart>
</div>
<?php /**PATH D:\xampp\htdocs\Learnig_Project\php learn\laravel_ecommerce\resources\views/website/ecommerce/layouts/header_cart.blade.php ENDPATH**/ ?>