<div class="logo hm3-logo">
    <a href="/">
        <img src="<?php echo e(asset('contents/website')); ?>/img/logo/1.png" alt="" />
    </a>
</div>
<?php /**PATH /home/hsblco55/oneclick.hsblco.com/resources/views/website/ecommerce/layouts/logo.blade.php ENDPATH**/ ?>