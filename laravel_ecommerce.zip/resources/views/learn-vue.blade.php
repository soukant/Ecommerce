@extends('website.ecommerce.layouts.ecommerce')
@section('content')
    {{-- <div class="row" style="margin: 100px 0px;" id="app">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <blog-list></blog-list>
                </div>
            </div>
        </div>
    </div> --}}
@endsection
