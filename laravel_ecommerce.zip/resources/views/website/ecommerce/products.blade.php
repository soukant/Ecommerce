@extends('website.ecommerce.layouts.ecommerce')
@section('content')
<div class="main-container shop-bg">
    <div class="container" id="category_product">
        <category-product></category-product>
    </div>
</div>

@endsection
