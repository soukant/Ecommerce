<div class="top-cart home3-top-cart home3-bg bg-5" id="productCart">
    <product-header-cart></product-header-cart>
</div>
